package com.itheima.health.service;

import com.itheima.health.HealthException;
import com.itheima.health.entity.PageResult;
import com.itheima.health.entity.QueryPageBean;
import com.itheima.health.pojo.CheckItem;

import java.util.List;

/**
 * @ClassName CheckItemService
 * @Author Administrator
 * @Date 2020/9/18
 */
public interface CheckItemService {
    /**
     * 查询所有
     */
    List<CheckItem> findAll();

    /**
     *  添加检查项
     */
    void add(CheckItem checkitem);

    /**
     * 条件分页查询
     */
    PageResult<CheckItem> findPage(QueryPageBean queryPageBean);

    /**
     * 通过id查询
     */
    CheckItem findById(int id);

    /**
     * 修改检查项
     */
    void update(CheckItem checkitem);

    /**
     * 通过id删除
     */
    void deleteById(int id) throws HealthException;
}
