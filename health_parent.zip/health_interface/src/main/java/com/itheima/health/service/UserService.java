package com.itheima.health.service;

import com.itheima.health.pojo.User;

/**
 * @ClassName CheckItemService
 * @Author Administrator
 * @Date 2020/9/28
 */
public interface UserService {
    /**
     * 获取用户的角色权限信息
     */
    User findByUsername(String username);
}
