package com.itheima.health.service;

import java.util.Map;

/**
 * @ClassName CheckItemService
 * @Author Administrator
 * @Date 2020/9/28
 */
public interface ReportService {
    /**
     * 运营数据统计
     */
    Map<String, Object> getBusinessReportData();
}
