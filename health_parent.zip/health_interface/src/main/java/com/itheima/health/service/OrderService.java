package com.itheima.health.service;

import com.itheima.health.HealthException;
import com.itheima.health.pojo.Order;

import java.util.Map;

/**
 * @ClassName CheckItemService
 * @Author Administrator
 * @Date 2020/9/28
 */
public interface OrderService {

    /**
     * 提交预约
     */
    Order submit(Map<String, String> orderInfo) throws HealthException;

    /**
     * 订单详情
     */
    Map<String, String> findById(int id);
}
