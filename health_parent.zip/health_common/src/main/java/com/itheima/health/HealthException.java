package com.itheima.health;

/**
 * @ClassName HealthException
 * @Author Administrator
 * @Date 2020/9/19
 */
public class HealthException extends RuntimeException {
    public HealthException(String message){
        super(message);
    }
}
