package com.itheima.health.dao;

import com.github.pagehelper.Page;
import com.itheima.health.pojo.CheckItem;

import java.util.List;

/**
 * @ClassName CheckItemDao
 * @Author Administrator
 * @Date 2020/9/19
 */
public interface CheckItemDao {
    /**
     * 查询所有
     */
    List<CheckItem> findAll();

    /**
     * 添加检查项
     */
    void add(CheckItem checkItem);

    /**
     * 通过id删除
     */
    void deleteById(int id);

    /**
     * 统计个数检查组与检查项的关系表 条件检查的id=id
     */
    int findCountByCheckItemId(int id);

    /**
     * 通过id查询
     */
    CheckItem findById(int id);

    /**
     * 分页条件查询
     */
    Page<CheckItem> findByCondition(String queryString);

    /**
     * 修改检查项
     */
    void update(CheckItem checkitem);

}
