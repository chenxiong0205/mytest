package com.itheima.health.dao;

import com.github.pagehelper.Page;
import com.itheima.health.pojo.Member;

import java.util.List;

/**
 * @ClassName MemberDao 
 * @Author Administrator
 * @Date 2020/9/25
 */
public interface MemberDao {
    /**
     * 查询所有
     */
    List<Member> findAll();

    /**
     * 分页查询
     */
    Page<Member> selectByCondition(String queryString);

    /**
     * 添加会员
     */
    void add(Member member);

    /**
     * 通过id删除
     */
    void deleteById(Integer id);

    /**
     * 通过id查询
     */
    Member findById(Integer id);

    /**
     * 通过手机号码查询会员信息
     */
    Member findByTelephone(String telephone);

    /**
     * 修改会员
     */
    void edit(Member member);

    /**
     * 统计在某个日期前为止，会员总数量
     */
    Integer findMemberCountBeforeDate(String date);

    /**
     * 统计某个日期的新增会员数量
     */
    Integer findMemberCountByDate(String date);

    Integer findMemberCountAfterDate(String date);

    /**
     * 会员总数量
     */
    Integer findMemberTotalCount();
}
