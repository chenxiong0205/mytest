package com.itheima.health.dao;

import com.itheima.health.pojo.Order;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @ClassName OrderDao 
 * @Author Administrator
 * @Date 2020/9/25
 */
public interface OrderDao {
    /**
     * 添加订单
     */
    void add(Order order);

    /**
     * 预约订单查询
     */
    List<Order> findByCondition(Order order);

    /**
     * 订单详情
     */
    Map findById4Detail(Integer id);

    /**
     * 某个日期的预约数量
     */
    Integer findOrderCountByDate(String date);

    /**
     * 某个期后的预约数量
     */
    Integer findOrderCountAfterDate(String date);

    /**
     * 某个日期已到诊的数量
     */
    Integer findVisitsCountByDate(String date);

    /**
     * 从某个日期后到诊数量
     */
    Integer findVisitsCountAfterDate(String date);

    /**
     * 查询热门套餐
     */
    List<Map<String,Object>> findHotSetmeal();

    /**
     * 统计日期范围内的预约数量
     */
    int findOrderCountBetweenDate(@Param("startDate") String startDate, @Param("endDate") String endDate);
}
