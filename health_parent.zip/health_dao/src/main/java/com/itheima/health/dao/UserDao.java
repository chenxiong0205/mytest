package com.itheima.health.dao;

import com.itheima.health.pojo.User;

/**
 * @ClassName UserDao 
 * @Author Administrator
 * @Date 2020/9/25
 */
public interface UserDao {

    /**
     * 获取用户的角色权限信息
     */
    User findByUsername(String username);
}
